#include<stdio.h>
#include<stdlib.h>
#include "header.h"
extern node_t* head;
extern node_t* tail;

void searching(void){
    printf("\nThis is searching module\n");
}

void sort(void){
    printf("\nThis is sort module.\n");
}

void free_list(void){
    printf("\nThis is free list\n");
}

void init(void){
    node_t* head = NULL;
    node_t* tail = NULL;
}

int is_empty(void){
    return head==NULL && tail==NULL;
}

node_t* create_node(void){
    int data;
    node_t* new =(node_t*)malloc(sizeof(node_t));
    printf("Enter the data :: ");
    scanf("%d", &data);
    new->data=data;
    new->next = NULL;
    new->prev = NULL;
    return new;
}
