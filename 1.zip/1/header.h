#ifndef __header_h
#define __header_h

    // Structure definition
    typedef struct node{
        int data;
        struct node* next;
        struct node* prev;
    }node_t;

    void add_first(void);
    void add_last(void);
    void add_between(int);

    void del_first(void);
    void del_last(void);
    void del_between(void);

    void display_forward(void);
    void display_reverse(void);

    void searching(void);
    void sort(void);
    void free_list(void);

    void init(void);
    int is_empty(void);
    node_t* create_node(void);



#endif