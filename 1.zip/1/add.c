#include<stdio.h>
#include<stdlib.h>
#include "header.h"

extern node_t* head;
extern node_t* tail;

void add_first(void){
    printf("\nThis is add first.\n");
    node_t* new = create_node();

    if(is_empty()){
        head = new;
        tail = new;
    }
    else{
        new->next = head;
        new->prev = head->prev;
        head->next = new;
        head = new;
    }
}
void add_last(void){
    printf("\nThis is add last.\n");
    node_t* new = create_node();

    if(is_empty()){
        head = new;
        tail = new;
    }
    else{
        new->prev=tail;
        new->next=tail->next;
        tail->next=new;
        tail=new;
    }
}
void add_between(int pos){
    printf("\nThis is add between.\n");
    node_t* new = create_node();

    if(is_empty()){
        head = new;
        tail = new;
    }
    else if(pos<=1){
        free(new);
        add_first();
    }
    else{
        int i=1;
        node_t* trav = head;
        while (i++<pos-1 && trav!=NULL)
            trav=trav->next;
        new->next=trav->next;
        new->prev=trav;
        trav->next->prev=new;
        trav->next=new;
    }
}