#include<stdio.h>
#include "header.h"
extern node_t* head;
extern node_t* tail;

void del_first(void){
    printf("\nThis is del first.\n");
}
void del_last(void){
    printf("\nThis is del last.\n");
}
void del_between(void){
    printf("\nThis is del between.\n");
}