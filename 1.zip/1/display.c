#include<stdio.h>
#include "header.h"
extern node_t* head;
extern node_t* tail;

void display_forward(void){
    printf("\nThis is display forward\n");
    if(is_empty())
        printf("\nList is Empty.");
    else{
       node_t* trav = head;
        printf("\nForward List :: ");
        while(trav->next!=NULL){
            printf("\t%d", trav->data);
            trav = trav->next; 
        }
        printf("\n"); 
    }
    
}
void display_reverse(void){
    printf("\nThis is display reverse\n");
}
