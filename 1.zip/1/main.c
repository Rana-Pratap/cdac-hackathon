#include<stdio.h>
#include "header.h"
node_t* head;
node_t* tail;

int main(void){
    int ch;
    do{
        printf("\n0. Exit\n1. Add First\n2. Add Last\n3. Add Between\n4. Delete First\n5. Delete Last\n6. Delete Between\n7. Display Forward\n8. Display Reverse\n9. Search\n10. Sort\n11. Free List");
        printf("\nEnter your choice :: ");
        scanf("%d", &ch);

        switch(ch){
            case 0:            
                return 0;
            case 1:            
                add_first();break;
            case 2:            
                add_last();break;
            case 3:      
                int pos;
                printf("\nEnter position :: ");
                scanf("%d", &pos);       
                add_between(pos);break;
            case 4:            
                del_first();break;
            case 5:            
                del_last();break;
            case 6:
                           
                del_between();break;
            case 7:            
                display_forward();break;
            case 8:
                display_reverse(); break;            
            case 9:   
                searching();break;         
            case 10:            
                sort();break;
            case 11:
                free_list();break;
            default:
                printf("\n**Enter valid option**\n");            
        }
    }while(ch!=0);

    return 0;
}