#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"header.h"

void createQuote(){
	char fname[20];
	char lname[20];
	Users u;
	FILE* fu = fopen(USER_FILE, "rb");
	if(fu==NULL){
		perror("\nFailed to open User File");
		exit(1);
	}
	while(fread(&u, sizeof(Users),1, fu)>0){
		strcpy(fname,u.fname);
		strcpy(lname,u.lname);
	}
	fclose(fu);
		
	Quotes q;
	printf("Enter your quote :: ");
	scanf("%*c%[^\n]s",q.text);
	strcpy(q.author.fname, fname);
	strcpy(q.author.lname, lname);

	FILE *fp = fopen(QUOTES_FILE,"ab");
	if(fp==NULL){
		perror("\n**Failed to open quote file**\n");
		exit(1);
	}
	fwrite(&q, sizeof(Quotes), 1, fp);
	fclose(fp);
	printf("**Thank You! Your Quote saved Successfully***\n\n");
}
void readQuote(){
	char fname[20];
	char lname[20];
	Users u;
	FILE* fu = fopen(USER_FILE, "rb");
	if(fu==NULL){
		perror("\nFailed to open User File");
		exit(1);
	}
	while(fread(&u, sizeof(Users),1, fu)>0){
		strcpy(fname,u.fname);
		strcpy(lname,u.lname);
	}
	fclose(fu);
		
	Quotes q;
	FILE* fp = fopen(QUOTES_FILE, "rb");
	if(fp==NULL){
		perror("\nFailed to open Quote File.");
		exit(1);
	}
	while(fread(&q, sizeof(Quotes), 1, fp)>0)
		printf("[%s\t%s %s]",q.text, fname, lname);
	fclose(fp);	
}
