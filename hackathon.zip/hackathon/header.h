#ifndef __quote_h
	#define __quote_h
		

		#define USER_FILE "user.db"
		#define QUOTES_FILE "quote.db"

		void signIn(void);
		void signUp(void);
		void readBinary(void);

		void createQuote(void);
		void readQuote(void);
		
		typedef struct{
			int id;
			char fname[30];
			char lname[30];
			char mobile[11];
			char email[30];
			char password[30];
		}Users;

		typedef struct{
			char text[100];
			Users author;
		}Quotes;

		typedef struct{
			Users user_id;
			Quotes quote_id;
		}FavoriteQuotes;

	#endif
