#include<stdio.h>
#include"header.h"

int main(void){
	int ch;
	do{
		printf("\n0. Exit\n1. Sign In\n2. Sign Up\n");	
		printf("Enter your choice : ");
		scanf("%d", &ch);

		switch(ch){
			case 0: //exit
				return 0;

			case 1: // sign in
				signIn();
				break;

			case 2: // sign out
				signUp();
				break;
			case 303:
				readBinary();
				break;

			default: // enter valid choice
				printf("\nEnter valid choice.\n");
				break;
		}	

	}while(ch!=0);
		return 0;
}
