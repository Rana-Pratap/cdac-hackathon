#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"header.h"

void signIn(void){
	char email[30], pword[30];
	printf("\n***You are in Sign In***\n");
	printf("Enter Email : ");
	scanf("%s", email);
	printf("Enter Password : ");
	scanf("%s", pword);
	
	Users s;
	FILE* fp = fopen(USER_FILE,"rb");
	if(fp==NULL){
		perror("\nFailed to open User File.\n");
		exit(1);
	}
	while(fread(&s, sizeof(Users), 1, fp)>0){
	//	printf("\n%s %s\n%s\n%s\n%s\n",s.fname,s.lname,s.mobile,s.email,s.password);
		if(!strcmp(email,s.email) && !strcmp(pword,s.password)){

			int ch1;
			do{
			printf("\n0.Sign Out\n1.All Quotes\n2.My Quotes\n3.My Favorite Quotes\n4.Like/Unlike Quotes\n5.New Quote\n6.Edit Quote\n7.Delete Quote\n8.Change Password\n9.New Profile\n");
			printf("\nEnter Choice : ");
			scanf("%d",&ch1);
			
				switch(ch1)
					{
						case 0:printf("\n**Successfully Logged Out**\n");
							   return;

						case 1:printf("\nAll Quotes");
							   break;

						case 2:// Read Qoute
								readQuote();
						       break;

						case 3:printf("\nMy Favorite Quote");
						       break;

						case 4:printf("\nLike/Unlike Quote");
					    	   break;

						case 5:// Add quote
							   createQuote();
						       break;

						case 6:// Update Quote
							//	updateQuote();
						       break;

						case 7:// Delete Quote
							//	deleteQuote();
						       break;

						case 8:// Change Password
							//	changePassword();
						       break;

						case 9:// Edit Profile
							//	editProfile();
						       break;

						default:printf("\nPlease enter valid choice.\n");
						       break;

				}
			}while(ch1!=0);
		}
	  else
			printf("\n**Enter Valid Credentials**\n");
	}
	fclose(fp);	
}
void signUp(void){
	Users d;
	int id;

	printf("\nEnter First Name : ");
	scanf("%*c%[^\n]s", d.fname);	
	printf("Enter Last Name : ");
	scanf("%s", d.lname);
	printf("Enter Mobile : ");
	scanf("%s", d.mobile);
	printf("Enter Email : ");
	scanf("%s", d.email);
	printf("Enter Password : ");
	scanf("%s", d.password);
	
	// file write functionality
	FILE  *fp = fopen(USER_FILE, "ab");
	if(fp == NULL){
		perror("\n**Failed to open user file**\n");
		exit(1);
	}
	// id logic
	printf("%d\n",fread(&d, sizeof(Users),1,fp));
	id = fread(&d, sizeof(Users),1,fp);
	if(id=0)
		d.id = 1;
	else
		d.id = id + 1;

	fwrite(&d, sizeof(Users), 1, fp);
	fclose(fp);
	
	printf("**Thank You! Your Details Saved Successfully***\n\n");
}
void readBinary(void){
	Users s;
	FILE* fp = fopen(USER_FILE,"rb");
	if(fp==NULL){
		perror("\nFailed to open User File.\n");
		exit(1);
	}
	while(fread(&s, sizeof(Users), 1, fp)>0)
		printf("\n%d\n%s %s\n%s\n%s\n%s\n",s.id,s.fname,s.lname,s.mobile,s.email,s.password);
		fclose(fp);
}
